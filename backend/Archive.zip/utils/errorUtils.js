const throwErr = (err) => {
  throw new Error(err)
}

module.exports = { throwErr }
