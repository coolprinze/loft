const JWT_SECRET = 'ABC123'

module.exports = { JWT_SECRET }
